
const config = { backendEndpoint: "https://crio-qtrip-dynamic-vint.onrender.com" };

export default config;
