// CRIO_SOLUTION_START_MODULE_UNDERSTANDING_BASICS
// CRIO_SOLUTION_END_MODULE_UNDERSTANDING_BASICS
module.exports.userValidation = require("./user.validation");
module.exports.authValidation = require("./auth.validation");
module.exports.productValidation = require("./product.validation");
module.exports.cartValidation = require("./cart.validation");
