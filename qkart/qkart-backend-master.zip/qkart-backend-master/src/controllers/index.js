// CRIO_SOLUTION_START_MODULE_UNDERSTANDING_BASICS
// CRIO_SOLUTION_END_MODULE_UNDERSTANDING_BASICS
module.exports.userController = require("./user.controller");
module.exports.authController = require("./auth.controller");
module.exports.productController = require("./product.controller");
module.exports.cartController = require("./cart.controller");
