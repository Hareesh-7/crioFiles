
const config = { backendEndpoint: "https://crio-qtrip-dynamic-vint.onrender.com" };
// const config = { backendEndpoint: "http://15.207.210.160:8082" };

export default config;
