
const config = { backendEndpoint: "http://13.232.20.23:8082" };

export default config;
