
import AdminUI from './components/AdminUI';
import './App.css';

const App = () => {
  return (
    <main>
      < AdminUI />
    </main>
  );
};

export default App;
