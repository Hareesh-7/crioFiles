export const CheckBox = (props) => {
  return <input className={props.class} id={props.id} type="checkbox" />;
};
