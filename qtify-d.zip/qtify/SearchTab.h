#ifndef SEARCHTAB_H_
#define SEARCHTAB_H_

#include <QWidget>
#include <QVBoxLayout>
#include <Track.h>

#include "TabBase.h"
#include "PlayQueueWidget.h"
#include "PlayWidget.h"

class SearchTab : public TabBase
{
	Q_OBJECT

	public:
		SearchTab(QString query, PlayWidget *player, QWidget *parent = 0);
		QString query();
		void setSearchResults(QList<Track *> results);
		PlayQueueWidget * getPlayQueue();

	private:
		QVBoxLayout *layoutSearch;
		QString searchQuery;
		PlayQueueWidget *playQueue;
		PlayWidget *playWidget;

	private slots:
		void queueItemClicked(PlayQueueItem *);
};

#endif
