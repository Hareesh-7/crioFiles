#ifndef MAINWINDOW_H_
#define MAINWINDOW_H_

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QSlider>
#include <QtGui/QSpacerItem>
#include <QtGui/QTreeWidget>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include <QList>
#include <Track.h>
#include <Session.h>
#include <Playlist.h>
#include "TrackListItem.h"
#include <QPixmap>
#include "AboutWindow.h"
#include "TabWidget.h"
#include "SearchWidget.h"
#include "PlayWidget.h"
#include "PlaylistAction.h"

class MainWindow : public QMainWindow
{
	Q_OBJECT

	public:
		MainWindow(Session *session, QWidget *parent = 0, Qt::WindowFlags f = 0);

	private:
		QAction *actionExit;
		QWidget *centralwidget;
		QVBoxLayout *verticalLayout_2;
		QHBoxLayout *layoutSearch;
		SearchWidget *searchWidget;
		QMenuBar *menubar;
		QMenu *menuFile;
		Session *spotifySession;
		QMenu *menuPlaylists;
		QAction *actionNewPlaylist;
		QMenu *menuHelp;
		QAction *actionAbout;
		TabWidget *tabWidget;
		PlayWidget *playerWidget;
		QList<Playlist *> *playlists;

	public slots:
		void showAbout();
		void refreshPlaylists();
		void openPlaylist(QAction *);
};


#endif
