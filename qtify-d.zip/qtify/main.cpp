#include <QApplication>
#include <QMessageBox>
#include "LoginWindow.h"
#include "MainWindow.h"
#include <Session.h>
#include <QDir>

int main(int argc, char ** argv)
{
	QApplication app( argc, argv );

	Session *session = new Session();

	QCoreApplication::setOrganizationName("Qtify");
	QCoreApplication::setApplicationName(QString::fromUtf8("Qtify"));

	QDir path = QDir::homePath();

	if  (!path.exists(".qtify"))
	{
		path.mkdir(".qtify");
	}

	path.setPath(QDir::homePath() + "/.qtify");

	printf("Cache path: %s\n", path.absolutePath().toStdString().c_str());

	if (session->initSession("Qtify", path.absolutePath(), path.absolutePath()))
	{
		LoginWindow *loginWindow = new LoginWindow(session);
		if (loginWindow->exec() == QDialog::Accepted)
		{
				app.connect( &app, SIGNAL( lastWindowClosed() ), &app, SLOT( quit() ) );
				MainWindow *mainWindow = new MainWindow(session);
				mainWindow->show();
		}
		else
		{
			return 0;
		}

	}


	return app.exec();
}
