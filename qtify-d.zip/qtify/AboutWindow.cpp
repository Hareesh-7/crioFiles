#include "AboutWindow.h"

AboutWindow::AboutWindow(QWidget *parent, Qt::WindowFlags f)
{
	setWindowFlags(Qt::Popup);
	//setWindowModality(Qt::WindowModal);
	setFixedSize(330, 240);
	setModal(true);

	gridLayout = new QGridLayout(this);
	gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
	verticalLayout_2 = new QVBoxLayout();
	verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
	horizontalLayout = new QHBoxLayout();
	horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
	spacerLeftLogo = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

	horizontalLayout->addItem(spacerLeftLogo);

	verticalLayout = new QVBoxLayout();
	verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
	labelPoweredBy = new QLabel(this);
	labelPoweredBy->setObjectName(QString::fromUtf8("labelPoweredBy"));
	labelPoweredBy->setAlignment(Qt::AlignCenter);

	verticalLayout->addWidget(labelPoweredBy);

	labelSpotifyCore = new QLabel(this);
	labelSpotifyCore->setObjectName(QString::fromUtf8("labelSpotifyCore"));
	QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
	sizePolicy.setHorizontalStretch(0);
	sizePolicy.setVerticalStretch(0);
	sizePolicy.setHeightForWidth(labelSpotifyCore->sizePolicy().hasHeightForWidth());
	labelSpotifyCore->setSizePolicy(sizePolicy);
	labelSpotifyCore->setMinimumSize(QSize(128, 128));
	labelSpotifyCore->setMaximumSize(QSize(128, 128));
	labelSpotifyCore->setPixmap(QPixmap(QString::fromUtf8(":/images/images/spotify-core.png")));

	verticalLayout->addWidget(labelSpotifyCore);


	horizontalLayout->addLayout(verticalLayout);

	spacerRightLogo = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

	horizontalLayout->addItem(spacerRightLogo);


	verticalLayout_2->addLayout(horizontalLayout);

	labelLegal = new QLabel(this);
	labelLegal->setObjectName(QString::fromUtf8("labelLegal"));
	labelLegal->setWordWrap(true);

	verticalLayout_2->addWidget(labelLegal);


	gridLayout->addLayout(verticalLayout_2, 0, 0, 1, 1);


	setWindowTitle("About Qtify - Beta");
	labelPoweredBy->setText("Powered by:");
	labelSpotifyCore->setText(QString());
	labelLegal->setText("This product uses SPOTIFY(R) CORE but is not endorsed, certified or otherwise approved in any way by Spotify. Spotify is the registered trade mark of the Spotify Group.");
}
