#ifndef PLAYQUEUEWIDGET_H_
#define PLAYQUEUEWIDGET_H_

#include <QVBoxLayout>
#include <QList>
#include <QWidget>
#include <QTreeWidget>
#include <QtGui/QHeaderView>
#include <Track.h>

#include "PlayQueueTree.h"
#include "PlayQueueItem.h"

class PlayQueueWidget : public QWidget
{
	Q_OBJECT

	public:
		PlayQueueWidget(QWidget *parent = 0);
		void addTrack(PlayQueueItem *item);
		void addTracks(QList<PlayQueueItem *> items);
		void insertTrack(PlayQueueItem *item, int index);
		void clearQueue();
		void setContextMenu(QMenu *menu);
		void resizeColumns();
		PlayQueueItem *getQueueItem(int index);
		int count();
		int indexOf(PlayQueueItem *item);
		int setSortable(bool sortable);


	private slots:
		void itemDoubleClicked(QTreeWidgetItem *, int);

	private:
		QVBoxLayout *layoutPlayQueue;
		PlayQueueTree *treePlayQueue;

	signals:
		void queueItemClicked(PlayQueueItem *);

};


#endif
