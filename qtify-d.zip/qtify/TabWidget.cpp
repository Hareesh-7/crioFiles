#include "TabWidget.h"

TabWidget::TabWidget(PlayWidget *player, QWidget *parent) : QWidget(parent)
{
	playerWidget = player;

	layoutTab = new QVBoxLayout(this);
	layoutTab->setMargin(0);

	tabWidget = new QTabWidget(this);
	tabWidget->setAutoFillBackground(true);
	tabWidget->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding));
	tabWidget->setMovable(true);
	tabWidget->setTabsClosable(true);

	layoutTab->addWidget(tabWidget);

	connect(tabWidget, SIGNAL(tabCloseRequested (int)), this, SLOT(closeTab(int)));
}

TabBase *TabWidget::openSearchTab(QString query)
{
	TabBase *tab;

	for (int x = 0; x < tabWidget->count(); x++)
	{
		tab = (TabBase *)tabWidget->widget(x);

		if (tab->tabType() == TabBase::SearchTab)
		{
			if (((SearchTab *)tab)->query() == query)
			{
				tabWidget->setCurrentWidget(tab);
				return (SearchTab *)tab;
			}
		}
	}

	tab = new SearchTab(query, playerWidget);

	tabWidget->addTab(tab, QIcon(":/images/images/search.png"), query);
	tabWidget->setCurrentWidget(tab);

	return (SearchTab *)tab;
}

TabBase *TabWidget::openPlaylistTab(Playlist *pl)
{
	TabBase *tab;

		for (int x = 0; x < tabWidget->count(); x++)
		{
			tab = (TabBase *)tabWidget->widget(x);

			if (tab->tabType() == TabBase::PlaylistTab)
			{
				if (((PlaylistTab *)tab)->id() == pl->id())
				{
					tabWidget->setCurrentWidget(tab);
					return (PlaylistTab *)tab;
				}
			}
		}

		tab = new PlaylistTab(pl, playerWidget);

		tabWidget->addTab(tab, QIcon(":/images/images/playlist.png"), pl->name());
		tabWidget->setCurrentWidget(tab);

		return (PlaylistTab *)tab;
}

void TabWidget::closeTab(int index)
{
	tabWidget->removeTab(index);
}

TabBase *TabWidget::activeTab()
{
	if (tabWidget->count() > 0 && tabWidget->currentIndex() >= 0)
	{
		return (TabBase *)tabWidget->currentWidget();
	}

	return NULL;
}
