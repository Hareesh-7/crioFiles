#ifndef __LOGINWINDOW_H__
#define __LOGINWINDOW_H__

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>

#include <Session.h>

class LoginWindow : public QDialog
{
	Q_OBJECT

	public:
		LoginWindow(Session *session, QWidget *parent = 0, Qt::WindowFlags f = 0);

	private:
		QGridLayout *gridLayout;
		QVBoxLayout *layoutLogin;
		QHBoxLayout *layoutUsername;
		QLabel *labelUsername;
		QSpacerItem *spacerUsername;
		QLineEdit *textBoxUsername;
		QHBoxLayout *layoutPassword;
		QLabel *labelPassword;
		QSpacerItem *spacerPassword;
		QLineEdit *textBoxPassword;
		QSpacerItem *spacerLogin;
		QHBoxLayout *layoutButtons;
		QSpacerItem *spacerButtons;
		QPushButton *buttonCancel;
		QPushButton *buttonOk;
		QLabel *labelError;

		Session *spotifySession;

	private slots:
		void loggedIn(int errorCode);
		void login();
		void quit();

};

#endif
