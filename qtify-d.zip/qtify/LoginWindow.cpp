#include "LoginWindow.h"

LoginWindow::LoginWindow(Session *session, QWidget *parent, Qt::WindowFlags f) : QDialog(parent, f)
{
	spotifySession = session;

	setFixedSize(326, 147);
	setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	setSizeGripEnabled(false);
	setModal(true);
	setWindowTitle(QString::fromUtf8("Spotify Login"));

	gridLayout = new QGridLayout(this);

	layoutLogin = new QVBoxLayout();

	layoutUsername = new QHBoxLayout();

	labelUsername = new QLabel(this);
	labelUsername->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	labelUsername->setText(QString::fromUtf8("Username:"));

	spacerUsername = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

	textBoxUsername = new QLineEdit(this);
	textBoxUsername->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	textBoxUsername->setMinimumSize(QSize(200, 0));


	layoutUsername->addWidget(labelUsername);
	layoutUsername->addItem(spacerUsername);
	layoutUsername->addWidget(textBoxUsername);

	layoutPassword = new QHBoxLayout();

	labelPassword = new QLabel(this);
	labelPassword->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	labelPassword->setText(QString::fromUtf8("Password:"));

	spacerPassword = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

	textBoxPassword = new QLineEdit(this);
	textBoxPassword->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	textBoxPassword->setMinimumSize(QSize(200, 0));
	textBoxPassword->setEchoMode(QLineEdit::Password);


	layoutPassword->addWidget(labelPassword);
	layoutPassword->addItem(spacerPassword);
	layoutPassword->addWidget(textBoxPassword);

	spacerLogin = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

	layoutButtons = new QHBoxLayout();

	spacerButtons = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

	buttonCancel = new QPushButton(this);
	buttonCancel->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	buttonCancel->setText(QString::fromUtf8("Cancel"));

	buttonOk = new QPushButton(this);
	buttonOk->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	buttonOk->setText(QString::fromUtf8("Ok"));
	buttonOk->setDefault(true);

	layoutButtons->addItem(spacerButtons);
	layoutButtons->addWidget(buttonCancel);
	layoutButtons->addWidget(buttonOk);

	labelError = new QLabel(this);
	labelError->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Expanding);

	layoutLogin->addLayout(layoutUsername);
	layoutLogin->addLayout(layoutPassword);
	layoutLogin->addItem(spacerLogin);
	layoutLogin->addLayout(layoutButtons);
	layoutLogin->addWidget(labelError);

	gridLayout->addLayout(layoutLogin, 0, 0, 1, 1);


	connect(spotifySession, SIGNAL(loggedIn(int)), this, SLOT(loggedIn(int)));
	connect(buttonOk, SIGNAL(clicked()), this, SLOT(login()));
	connect(buttonCancel, SIGNAL(clicked()), this, SLOT(quit()));

}

void LoginWindow::loggedIn(int errorCode)
{
	Session::Error code = (Session::Error)errorCode;

	if (code == Session::OK)
	{
		accept();
	}
	else
	{
		labelError->setText("Login failed: " + spotifySession->getLastErrorMsg());
	}
}

void LoginWindow::login()
{
	spotifySession->login(textBoxUsername->text(), textBoxPassword->text());
	labelError->setText("Logging in to Spotify...");
}

void LoginWindow::quit()
{
	reject();
}
