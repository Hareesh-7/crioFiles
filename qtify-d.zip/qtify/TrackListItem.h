#ifndef TRACKLISTITEM_H_
#define TRACKLISTITEM_H_

#include <QTreeWidgetItem>
#include <QString>
#include <Track.h>

class TrackListItem : public QTreeWidgetItem
{
	public:
		TrackListItem(Track *track);
		Track *getTrack();
		QString getTrackName();
		QString getArtist();
		int getLength();
		QString getLengthString();

	private:
		Track *t;
};

#endif
