#include "SearchWidget.h"

SearchWidget::SearchWidget(Session *session, TabWidget *tabs, QWidget *parent) : QWidget(parent)
{
	spotifySession = session;
	tabWidget = tabs;

	layoutSearch = new QHBoxLayout(this);
	layoutSearch->setMargin(0);

	textBoxSearch = new QLineEdit(this);
	textBoxSearch->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	textBoxSearch->setMinimumSize(QSize(200, 0));

	buttonSearch = new QPushButton(this);
	buttonSearch->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	buttonSearch->setMaximumSize(QSize(100, 16777215));
	buttonSearch->setText("Search");
	buttonSearch->setIcon(QIcon(":/images/images/search.png"));

	spacerSearch = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

	layoutSearch->addWidget(textBoxSearch);
	layoutSearch->addWidget(buttonSearch);
	layoutSearch->addItem(spacerSearch);

	connect(buttonSearch, SIGNAL(clicked()), this, SLOT(search()));
	connect(textBoxSearch, SIGNAL(returnPressed()), this, SLOT(search()));
	connect(spotifySession, SIGNAL(searchResultReady()), this, SLOT(searchResultReady()));
}

void SearchWidget::search()
{
	if (textBoxSearch->text().length() > 0)
	{
		spotifySession->startSearch(textBoxSearch->text(), 0, 100);
		textBoxSearch->setEnabled(false);
		buttonSearch->setEnabled(false);
	}
}

void SearchWidget::searchResultReady()
{
	QList<Track *> tracks = spotifySession->getSearchResult();

	SearchTab *tab = (SearchTab *)tabWidget->openSearchTab(textBoxSearch->text());
	tab->setSearchResults(tracks);

	textBoxSearch->setEnabled(true);
	buttonSearch->setEnabled(true);
}
