#ifndef PLAYWIDGET_H_
#define PLAYWIDGET_H_

#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QHBoxLayout>
#include <QPushButton>
#include <QHBoxLayout>
#include <QSlider>
#include <QImage>
#include <QVariant>
#include <Session.h>

//#include "TabWidget.h"
//#include "TabBase.h"
#include "PlayQueueWidget.h"
#include "PlayQueueItem.h"


class PlayWidget : public QWidget
{
	Q_OBJECT

	public:
		PlayWidget(Session *session, QWidget *parent = 0) ;

	private:
		QVBoxLayout *layoutControl;
		QLabel *labelPlaying;
		QHBoxLayout *layoutSongControl;
		QHBoxLayout *layoutPlayButtons;
		QPushButton *buttonPrevious;
		QPushButton *buttonPlayPause;
		QPushButton *buttonNext;
		QHBoxLayout *layoutProgress;
		QLabel *labelPlayed;
		QSlider *sliderSongProgress;
		QLabel *labelLength;
		QLabel *labelImage;
		QHBoxLayout *layoutImage;
		Session *spotifySession;
		bool playing;
		PlayQueueWidget *currentQueue;
		PlayQueueItem *currentQueueItem;

		void setPlayedTime(int pos);
		void loadQueueItem(int index);

	public slots:
		void playbackEnded();
		void play();
		void prev();
		void next();
		void loadQueueItem(PlayQueueWidget *queue, PlayQueueItem *queueItem);


	private slots:
		void coverReady(QImage *);
		void trackPositionChanged(int);

};

#endif
