#include "SearchTab.h"

SearchTab::SearchTab(QString query, PlayWidget *player, QWidget *parent) : TabBase(TabBase::SearchTab, parent)
{
	searchQuery = query;
	playWidget = player;

	layoutSearch = new QVBoxLayout(this);
	layoutSearch->setMargin(0);

	playQueue = new PlayQueueWidget(this);
	playQueue->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding));

	layoutSearch->addWidget(playQueue);

	connect(playQueue, SIGNAL(queueItemClicked(PlayQueueItem *)), this, SLOT(queueItemClicked(PlayQueueItem *)));
}

QString SearchTab::query()
{
	return searchQuery;
}

void SearchTab::setSearchResults(QList<Track *> results)
{
	playQueue->clearQueue();

	while (!results.isEmpty())
	{
		Track *track = results.takeFirst();

		playQueue->addTrack(new PlayQueueItem(track));
	}

	playQueue->resizeColumns();
}

PlayQueueWidget * SearchTab::getPlayQueue()
{
	return playQueue;
}

void SearchTab::queueItemClicked(PlayQueueItem *item)
{
	playWidget->loadQueueItem(playQueue, item);
	playWidget->play();
}
