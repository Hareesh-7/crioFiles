#include "MainWindow.h"

MainWindow::MainWindow(Session *session, QWidget *parent, Qt::WindowFlags f) : QMainWindow(parent, f)
{
	spotifySession = session;

	resize(800, 600);
	setWindowTitle("Qtify - Beta");

	menubar = new QMenuBar(this);
	menubar->setGeometry(QRect(0, 0, 800, 23));

	actionExit = new QAction(this);
	actionExit->setText("Exit");
	actionExit->setIcon(QIcon(":/images/images/exit.png"));

	menuFile = new QMenu(menubar);
	menuFile->addAction(actionExit);
	menuFile->setTitle("File");

	menubar->addAction(menuFile->menuAction());

	actionNewPlaylist = new QAction(this);
	actionNewPlaylist->setText("New Playlist");
	actionNewPlaylist->setIcon(QIcon(":/images/images/add.png"));

	menuPlaylists = new QMenu(menubar);
	menuPlaylists->setTitle("Playlists");



	menubar->addAction(menuPlaylists->menuAction());

	actionAbout = new QAction(this);
	actionAbout->setText("About");
	actionAbout->setIcon(QIcon(":/images/images/about.png"));

	menuHelp = new QMenu(menubar);
	menuHelp->setTitle("Help");
	menuHelp->addAction(actionAbout);

	menubar->addAction(menuHelp->menuAction());

	setMenuBar(menubar);

	centralwidget = new QWidget(this);

	setCentralWidget(centralwidget);

	verticalLayout_2 = new QVBoxLayout(centralwidget);

	playerWidget = new PlayWidget(spotifySession, this);

	tabWidget = new TabWidget(playerWidget, centralwidget);
	tabWidget->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding));

	searchWidget = new SearchWidget(spotifySession, tabWidget, this);

	verticalLayout_2->addWidget(searchWidget);
	verticalLayout_2->addWidget(tabWidget);
	verticalLayout_2->addWidget(playerWidget);

	connect(actionExit, SIGNAL(triggered()), this, SLOT(close()));
	connect(actionAbout, SIGNAL(triggered()), this, SLOT(showAbout()));
	connect(menuPlaylists, SIGNAL(triggered(QAction *)), this, SLOT(openPlaylist(QAction *)));

	refreshPlaylists();
}

void MainWindow::showAbout()
{
	AboutWindow *aboutWindow = new AboutWindow(this);

	int left = (width() / 2) - (aboutWindow->width() / 2) + x();
	int top = (height() / 2) - (aboutWindow->height() / 2) + y();

	aboutWindow->setGeometry(left, top, aboutWindow->width(), aboutWindow->height());
	aboutWindow->exec();
}

void MainWindow::refreshPlaylists()
{
	foreach(QAction *a, menuPlaylists->actions())
	{
		menuPlaylists->removeAction(a);
	}

	playlists = spotifySession->getPlaylists();

	menuPlaylists->addAction(actionNewPlaylist);
	menuPlaylists->addSeparator();


	for(int x = 0; x < playlists->count(); x++)
	{
		menuPlaylists->addAction(new PlaylistAction(playlists->at(x), this));
		tabWidget->openPlaylistTab(playlists->at(x));
	}
}

void MainWindow::openPlaylist(QAction *plAction)
{
	PlaylistAction *action = (PlaylistAction *)plAction;

	tabWidget->openPlaylistTab(action->playlist());
}




