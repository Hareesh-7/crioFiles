#ifndef TABWIDGET_H_
#define TABWIDGET_H_

#include <QWidget>
#include <QTabWidget>
#include <QVBoxLayout>
#include <Playlist.h>

#include "TabBase.h"
#include "SearchTab.h"
#include "PlaylistTab.h"
#include "PlayWidget.h"

class TabWidget : public QWidget
{
	Q_OBJECT

	public:
		TabWidget(PlayWidget *player, QWidget *parent = 0);
		TabBase *openSearchTab(QString query);
		TabBase *openPlaylistTab(Playlist *pl);
		TabBase *activeTab();

	private:
		QVBoxLayout *layoutTab;
		QTabWidget *tabWidget;
		PlayWidget *playerWidget;

	private slots:
		void closeTab(int);
};

#endif
