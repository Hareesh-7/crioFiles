#ifndef PLAYQUEUETREE_H_
#define PLAYQUEUETREE_H_

#include <QTreeWidget>
#include <QContextMenuEvent>
#include <QMenu>

class PlayQueueTree : public QTreeWidget
{
	public:
		PlayQueueTree(QWidget *parent);
		void setContextMenu(QMenu *menu);

	protected:
		void contextMenuEvent  (QContextMenuEvent * e);

	private:
		QMenu *contextMenu;
};

#endif
