#ifndef TABBASE_H_
#define TABBASE_H_

#include <QWidget>

#include "PlayQueueWidget.h"

class TabBase : public QWidget
{
	public:
		enum TabType
		{
			SearchTab = 0,
			PlaylistTab = 1,
		};

		TabBase(TabType type, QWidget *parent = 0);
		TabBase::TabType tabType();
		virtual PlayQueueWidget *getPlayQueue();

	private:
		TabType _tabType;

};


#endif
