#include "PlayWidget.h"

PlayWidget::PlayWidget(Session *session,  QWidget *parent) : QWidget(parent)
{
	spotifySession = session;

	currentQueue = 0;
	currentQueueItem = 0;
	playing = false;

	layoutImage = new QHBoxLayout(this);
	layoutImage->setMargin(0);

	labelImage = new QLabel(this);
	labelImage->setFixedSize(100, 100);
	labelImage->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	labelImage->setFrameStyle(QFrame::StyledPanel | QFrame::Plain);
	labelImage->setText("No track loaded...");

	layoutControl = new QVBoxLayout();

	labelPlaying = new QLabel(this);
	labelPlaying->setText("No track loaded.");

	layoutSongControl = new QHBoxLayout();

	layoutPlayButtons = new QHBoxLayout();

	buttonPrevious = new QPushButton(this);
	buttonPrevious->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	buttonPrevious->setFixedSize(QSize(50, 50));
	buttonPrevious->setIconSize(QSize(28, 28));
	buttonPrevious->setIcon(QIcon(":/images/images/prev.png"));
	buttonPrevious->setFlat(true);

	buttonPlayPause = new QPushButton(this);
	buttonPlayPause->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	buttonPlayPause->setFixedSize(QSize(50, 50));
	buttonPlayPause->setIconSize(QSize(32, 32));
	buttonPlayPause->setIcon(QIcon(":/images/images/play.png"));
	buttonPlayPause->setFlat(true);

	buttonNext = new QPushButton(this);
	buttonNext->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	buttonNext->setFixedSize(QSize(50, 50));
	buttonNext->setIconSize(QSize(28, 28));
	buttonNext->setIcon(QIcon(":/images/images/next.png"));
	buttonNext->setFlat(true);

	layoutPlayButtons->addWidget(buttonPrevious);
	layoutPlayButtons->addWidget(buttonPlayPause);
	layoutPlayButtons->addWidget(buttonNext);

	layoutProgress = new QHBoxLayout();

	labelPlayed = new QLabel(this);
	labelPlayed->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	labelPlayed->setText("0:00");

	sliderSongProgress = new QSlider(this);
	sliderSongProgress->setOrientation(Qt::Horizontal);
	sliderSongProgress->setInvertedAppearance(false);
	sliderSongProgress->setInvertedControls(false);
	sliderSongProgress->setEnabled(false);

	labelLength = new QLabel(this);
	labelLength->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed));
	labelLength->setText("0:00");

	layoutProgress->addWidget(labelPlayed);
	layoutProgress->addWidget(sliderSongProgress);
	layoutProgress->addWidget(labelLength);


	layoutSongControl->addLayout(layoutPlayButtons);
	layoutSongControl->addLayout(layoutProgress);

	layoutControl->addWidget(labelPlaying);
	layoutControl->addLayout(layoutSongControl);

	layoutImage->addWidget(labelImage);
	layoutImage->addLayout(layoutControl);

	connect(spotifySession, SIGNAL(trackPositionChanged(int)), this, SLOT(trackPositionChanged(int)));
	connect(spotifySession, SIGNAL(playbackEnded()), this, SLOT(playbackEnded()));
	connect(spotifySession, SIGNAL(coverReady(QImage *)), this, SLOT(coverReady(QImage *)));
	connect(buttonPlayPause, SIGNAL(clicked()), this, SLOT(play()));
	connect(buttonPrevious, SIGNAL(clicked()), this, SLOT(prev()));
	connect(buttonNext, SIGNAL(clicked()), this, SLOT(next()));
}

void PlayWidget::play()
{
	if (currentQueue == NULL)
	{
		/*TabBase *tab = tabWidget->activeTab();

		if (tab == NULL)
		{
			return;
		}

		currentQueue = tab->getPlayQueue();

		if (currentQueue == NULL)
		{
			return;
		}*/
		return;
	}

	if (currentQueueItem == NULL)
	{
		currentQueueItem = currentQueue->getQueueItem(0);

		if (currentQueueItem == NULL)
		{
			return;
		}

		loadQueueItem(0);
	}

	playing = !playing;

	spotifySession->play(playing);

	buttonPlayPause->setIcon(playing ? QIcon(":/images/images/pause.png") : QIcon(":/images/images/play.png"));
}

void PlayWidget::loadQueueItem(int index)
{
	playing = false;

	spotifySession->play(playing);

	currentQueueItem =  currentQueue->getQueueItem(index);

	labelImage->setPixmap(QPixmap());
	labelImage->setAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
	labelImage->setText("Loading\nalbum art");

	spotifySession->loadTrack(currentQueueItem->getTrack());
	sliderSongProgress->setMinimum(0);
	sliderSongProgress->setMaximum(currentQueueItem->getTrack()->length());
	sliderSongProgress->setValue(0);

	labelLength->setText(currentQueueItem->getLengthString());
	labelPlayed->setText("0:00");

	labelPlaying->setText(currentQueueItem->getArtist() + " - " + currentQueueItem->getTrackName());

	spotifySession->requestAlbumCover(currentQueueItem->getTrack());
}

void PlayWidget::loadQueueItem(PlayQueueWidget *queue, PlayQueueItem *queueItem)
{
	playing = false;

	spotifySession->play(playing);

	currentQueue = queue;
	loadQueueItem(currentQueue->indexOf(queueItem));
}

void PlayWidget::prev()
{
	int currentIndex;

	if (currentQueue == NULL)
	{
		return;
	}

	if (currentQueue->count() > 0)
	{
		if (currentQueueItem != NULL)
		{
			currentIndex = currentQueue->indexOf(currentQueueItem);
		}
		else
		{
			currentIndex = 0;
		}

		if (currentIndex != 0)
		{
			loadQueueItem(currentIndex - 1);
		}
		else
		{
			currentIndex = currentQueue->count() - 1;
			loadQueueItem(currentIndex);
		}

		play();
	}
}

void PlayWidget::next()
{
	int currentIndex;

	if (currentQueueItem == NULL)
	{
		return;
	}

	if (currentQueue->count() > 0)
	{
		if (currentQueueItem != NULL)
		{
			currentIndex = currentQueue->indexOf(currentQueueItem);
		}
		else
		{
			currentIndex = 0;
		}

		if (currentQueue->count() > currentIndex + 1)
		{
			loadQueueItem(currentIndex + 1);
		}
		else
		{
			currentIndex = 0;
			loadQueueItem(currentIndex);
		}

		play();
	}
}


void PlayWidget::trackPositionChanged(int pos)
{
	if (!sliderSongProgress->isSliderDown())
	{
		sliderSongProgress->setValue(pos);
		setPlayedTime(pos);
	}
}

void PlayWidget::setPlayedTime(int pos)
{
	int min = pos / 60000;
	int sec = (pos - (min * 60000)) / 1000;

	QString l;
	l.append(min < 10 ? "0" + QVariant(min).toString() : QVariant(min).toString());
	l.append(":" + (sec < 10 ? "0" + QVariant(sec).toString() : QVariant(sec).toString()));

	labelPlayed->setText(l);
}

void PlayWidget::playbackEnded()
{
	if (currentQueueItem != NULL && currentQueue->count() > 0)
	{
		int currentIndex = currentQueue->indexOf(currentQueueItem);

		if (currentQueue->count() > currentIndex + 1)
		{
			loadQueueItem(currentIndex + 1);
			play();
		}
		else
		{
			playing = false;
			buttonPlayPause->setIcon(QIcon(":/images/images/play.png"));
		}
	}
}

void PlayWidget::coverReady(QImage *image)
{
	QImage tmp = image->scaled(100, 100, Qt::KeepAspectRatio, Qt::SmoothTransformation);

	labelImage->setScaledContents(true);
	labelImage->setPixmap(QPixmap::fromImage(tmp));
}
