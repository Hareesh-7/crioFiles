#include "PlaylistAction.h"

PlaylistAction::PlaylistAction(Playlist *pl, QObject *parent) : QAction(parent)
{
	_playlist = pl;
	setText(_playlist->name());
	setIcon(QIcon(":/images/images/playlist.png"));
}

Playlist * PlaylistAction::playlist()
{
	return _playlist;
}
