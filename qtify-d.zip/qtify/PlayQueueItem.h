#ifndef PLAYQUEUEITEM_H_
#define PLAYQUEUEITEM_H_

#include <QTreeWidgetItem>
#include <QString>
#include <Track.h>

class PlayQueueItem : private QTreeWidgetItem
{
	friend class PlayQueueWidget;

	public:
		PlayQueueItem(Track *track);
		Track *getTrack();
		QString getTrackName();
		QString getArtist();
		int getLength();
		QString getLengthString();

	private:
		Track *t;
};

#endif
