#include "PlayQueueWidget.h"

PlayQueueWidget::PlayQueueWidget(QWidget *parent) : QWidget(parent)
{
	layoutPlayQueue = new QVBoxLayout(this);
	layoutPlayQueue->setMargin(0);

	QStringList columnTexts;
	columnTexts << "Track" << "Artist" << "Length" << "Album" << "Rating";

	treePlayQueue = new PlayQueueTree(this);
	treePlayQueue->setAlternatingRowColors(true);
	treePlayQueue->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
	treePlayQueue->setRootIsDecorated(false);
	treePlayQueue->setSortingEnabled(true);
	treePlayQueue->header()->setCascadingSectionResizes(false);
	treePlayQueue->setColumnCount(5);
	treePlayQueue->setHeaderLabels(columnTexts);
	treePlayQueue->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding));

	layoutPlayQueue->addWidget(treePlayQueue);

	connect(treePlayQueue, SIGNAL(itemDoubleClicked(QTreeWidgetItem *, int)), this, SLOT(itemDoubleClicked(QTreeWidgetItem *, int)));
}

void PlayQueueWidget::addTrack(PlayQueueItem *item)
{
	treePlayQueue->addTopLevelItem(item);
}

void PlayQueueWidget::addTracks(QList<PlayQueueItem *> items)
{
	while (!items.isEmpty())
	{
		treePlayQueue->addTopLevelItem(items.takeFirst());
	}
}

void PlayQueueWidget::insertTrack(PlayQueueItem *item, int index)
{
	treePlayQueue->insertTopLevelItem(index, item);
}

void PlayQueueWidget::clearQueue()
{
	treePlayQueue->clear();
}

void PlayQueueWidget::setContextMenu(QMenu *menu)
{
	treePlayQueue->setContextMenu(menu);
}

void PlayQueueWidget::resizeColumns()
{
	for (int x = 0; x < treePlayQueue->columnCount(); x++)
	{
		treePlayQueue->resizeColumnToContents(x);
		if (treePlayQueue->columnWidth(x) > 250)
		{
			treePlayQueue->setColumnWidth(x, 250);

		}
	}
}

PlayQueueItem *PlayQueueWidget::getQueueItem(int index)
{
	if (treePlayQueue->topLevelItemCount() > 0 && treePlayQueue->topLevelItemCount() >= index + 1)
	{
		treePlayQueue->setCurrentItem(treePlayQueue->topLevelItem(index));
		return (PlayQueueItem *)treePlayQueue->topLevelItem(index);
	}

	return NULL;
}

int PlayQueueWidget::count()
{
	return treePlayQueue->topLevelItemCount();
}

int PlayQueueWidget::indexOf(PlayQueueItem *item)
{
	return treePlayQueue->indexOfTopLevelItem(item);
}

void PlayQueueWidget::itemDoubleClicked(QTreeWidgetItem *item, int col)
{
	PlayQueueItem *queueItem = (PlayQueueItem *)item;

	emit queueItemClicked(queueItem);
}

int PlayQueueWidget::setSortable(bool sortable)
{
	treePlayQueue->setSortingEnabled(sortable);
}
