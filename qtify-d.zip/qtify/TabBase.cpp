#include "TabBase.h"

TabBase::TabBase(TabType type, QWidget *parent) : QWidget(parent)
{
	_tabType = type;
}

TabBase::TabType TabBase::tabType()
{
	return _tabType;
}

PlayQueueWidget *TabBase::getPlayQueue()
{
	return NULL;
}
