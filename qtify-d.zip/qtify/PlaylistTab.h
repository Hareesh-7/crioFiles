#ifndef PLAYLISTTAB_H_
#define PLAYLISTTAB_H_

#include <QWidget>
#include <QVBoxLayout>
#include <Track.h>
#include <Playlist.h>

#include "TabBase.h"
#include "PlayQueueWidget.h"
#include "PlayWidget.h"

class PlaylistTab : public TabBase
{
	Q_OBJECT

	public:
		PlaylistTab(Playlist *pl, PlayWidget *player, QWidget *parent = 0);
		QString id();
		PlayQueueWidget * getPlayQueue();

	private:
		QVBoxLayout *layoutSearch;
		QString searchQuery;
		PlayQueueWidget *playQueue;
		PlayWidget *playWidget;
		Playlist *playlist;

	private slots:
		void queueItemClicked(PlayQueueItem *);
};

#endif
