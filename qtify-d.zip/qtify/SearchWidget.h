#ifndef SEARCHWIDGET_H_
#define SEARCHWIDGET_H_

#include <QWidget>
#include <QHBoxLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QSpacerItem>
#include <Session.h>

#include "TabWidget.h"
#include "SearchTab.h"

class SearchWidget : public QWidget
{
	Q_OBJECT

	public:
		SearchWidget(Session *session, TabWidget *tabs, QWidget *parent = 0);

	private:
		QHBoxLayout *layoutSearch;
		QLineEdit *textBoxSearch;
		QPushButton *buttonSearch;
		QSpacerItem *spacerSearch;
		Session *spotifySession;
		TabWidget *tabWidget;

	private slots:
		void search();
		void searchResultReady();
};

#endif
