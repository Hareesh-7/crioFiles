#include "TrackListItem.h"

TrackListItem::TrackListItem(Track *track)
{
	t = track;
	setText(0, track->name());
	setText(1, track->artist());
	setText(3, track->album());

	int length = track->length() / 1000;

	int min = length / 60;
	int sec = length - (min * 60);

	QString l;
	l.append(min < 10 ? "0" + QVariant(min).toString() : QVariant(min).toString());
	l.append(":" + (sec < 10 ? "0" + QVariant(sec).toString() : QVariant(sec).toString()));

	setText(2, l);

	setText(4, QVariant(track->rating()).toString() + "%");
}

Track *TrackListItem::getTrack()
{
	return t;
}

QString TrackListItem::getTrackName()
{
	return t->name();
}

QString TrackListItem::getArtist()
{
	return t->artist();
}

int TrackListItem::getLength()
{
	return t->length();
}

QString TrackListItem::getLengthString()
{
	return text(2);
}
