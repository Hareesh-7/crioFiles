#include "PlayQueueTree.h"

PlayQueueTree::PlayQueueTree(QWidget *parent) : QTreeWidget(parent)
{
	contextMenu = 0;
}

void PlayQueueTree::setContextMenu(QMenu *menu)
{
	contextMenu = menu;
}

void PlayQueueTree::contextMenuEvent  (QContextMenuEvent * e)
{
	if (contextMenu != NULL)
	{
		contextMenu->exec(e->globalPos());
	}
}
