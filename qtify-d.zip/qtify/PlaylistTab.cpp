#include "PlaylistTab.h"

PlaylistTab::PlaylistTab(Playlist *pl, PlayWidget *player, QWidget *parent) : TabBase(TabBase::PlaylistTab, parent)
{
	playlist = pl;
	playWidget = player;

	layoutSearch = new QVBoxLayout(this);
	layoutSearch->setMargin(0);

	playQueue = new PlayQueueWidget(this);
	playQueue->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding));
	playQueue->setSortable(false);

	layoutSearch->addWidget(playQueue);

	for(int x = 0; x < playlist->trackList()->count(); x++)
	{
		playQueue->addTrack(new PlayQueueItem(playlist->trackList()->at(x)));
	}

	playQueue->resizeColumns();

	connect(playQueue, SIGNAL(queueItemClicked(PlayQueueItem *)), this, SLOT(queueItemClicked(PlayQueueItem *)));
}

QString PlaylistTab::id()
{
	return playlist->id();
}

PlayQueueWidget * PlaylistTab::getPlayQueue()
{
	return playQueue;
}

void PlaylistTab::queueItemClicked(PlayQueueItem *item)
{
	playWidget->loadQueueItem(playQueue, item);
	playWidget->play();
}
