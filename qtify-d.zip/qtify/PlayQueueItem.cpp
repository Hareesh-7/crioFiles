#include "PlayQueueItem.h"

PlayQueueItem::PlayQueueItem(Track *track)
{
	t = track;
	setText(0, track->name());
	setText(1, track->artist());
	setText(3, track->album());

	int length = track->length() / 1000;

	int min = length / 60;
	int sec = length - (min * 60);

	QString l;
	l.append(min < 10 ? "0" + QVariant(min).toString() : QVariant(min).toString());
	l.append(":" + (sec < 10 ? "0" + QVariant(sec).toString() : QVariant(sec).toString()));

	setText(2, l);

	setText(4, QVariant(track->rating()).toString() + "%");
}

Track *PlayQueueItem::getTrack()
{
	return t;
}

QString PlayQueueItem::getTrackName()
{
	return t->name();
}

QString PlayQueueItem::getArtist()
{
	return t->artist();
}

int PlayQueueItem::getLength()
{
	return t->length();
}

QString PlayQueueItem::getLengthString()
{
	return text(2);
}
