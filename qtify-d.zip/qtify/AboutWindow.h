#ifndef ABOUTWINDOW_H_
#define ABOUTWINDOW_H_

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>

class AboutWindow : public QDialog
{
	Q_OBJECT

	public:
		AboutWindow(QWidget *parent = 0, Qt::WindowFlags f = 0);

	private:
		QGridLayout *gridLayout;
		    QVBoxLayout *verticalLayout_2;
		    QHBoxLayout *horizontalLayout;
		    QSpacerItem *spacerLeftLogo;
		    QVBoxLayout *verticalLayout;
		    QLabel *labelPoweredBy;
		    QLabel *labelSpotifyCore;
		    QSpacerItem *spacerRightLogo;
		    QLabel *labelLegal;
};

#endif
