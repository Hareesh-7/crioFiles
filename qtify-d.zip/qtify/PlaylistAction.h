#ifndef PLAYLISTACTION_H_
#define PLAYLISTACTION_H_

#include <QAction>
#include <Playlist.h>

class PlaylistAction : public QAction
{
	public:
		PlaylistAction(Playlist *pl, QObject *parent);
		Playlist *playlist();

	private:
		Playlist *_playlist;

};


#endif
