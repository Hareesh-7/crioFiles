

export const accordionData= [

    {
        id:1,
        question: "IS QTIFY free to use?",
        answer: "Yes! It is 100% free, and it has 0% ads!",
    },
    {
        id:2,
        question: "Can I download and listen to songs offline?",
        answer: "Sorry, unfortunately we don't provide service to download any songs.",
    },

]