module.exports.User = require('./user.model').User
